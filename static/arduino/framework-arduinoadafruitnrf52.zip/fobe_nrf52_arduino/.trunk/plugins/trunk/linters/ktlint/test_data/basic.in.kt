class MainActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
      super.onCreate(savedInstanceState) // note the spacing
            setContentView(R.layout.activity_main)
  }
}
