class        Plumbus
  private






 def smooth; end
end
