import { linterFmtTest } from "tests";

linterFmtTest({ linterName: "markdown-table-prettify" });
