SeLEct  *, 1, blah as  fOO  from mySchema.myTable
