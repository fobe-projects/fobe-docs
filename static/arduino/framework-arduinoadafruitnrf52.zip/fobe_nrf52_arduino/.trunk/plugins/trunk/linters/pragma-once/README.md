# pragma-once

Formatter that ensures every header file begins with `#pragma once`
