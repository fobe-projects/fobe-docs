import { linterCheckTest } from "tests";

linterCheckTest({ linterName: "ty" });
