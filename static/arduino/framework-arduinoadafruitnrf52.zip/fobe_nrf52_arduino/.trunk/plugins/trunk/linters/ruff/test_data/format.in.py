
#whitespace below vvv

  #A malindented comment
if __name__ == "__main__" :
      a=4+1
      b=( 2*7 )
      c = [1,
           2,
           3
      ]
      print(a/b)
