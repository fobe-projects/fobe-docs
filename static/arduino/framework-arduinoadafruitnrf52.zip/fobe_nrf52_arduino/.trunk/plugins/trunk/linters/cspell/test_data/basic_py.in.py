def main():
    try:
        pass
    except (Exception, TypeError):
        pass

import sys
import pands

class NoDocstring(object):
    def __init__(self, arg1):
        self._attr1 = arg1

class Globe(object):
    def __init__(self):
        self.shape = 'spheroid'

    def __inti__(self):
        prit("this is not a valid method")
        callbak = lamda x: x * 2

    varName1 = "helol ym anme is var"

cachedir = "/tmp"
