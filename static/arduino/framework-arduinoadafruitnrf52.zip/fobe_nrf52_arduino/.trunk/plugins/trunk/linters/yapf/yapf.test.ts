import { linterFmtTest } from "tests";

linterFmtTest({ linterName: "yapf" });
