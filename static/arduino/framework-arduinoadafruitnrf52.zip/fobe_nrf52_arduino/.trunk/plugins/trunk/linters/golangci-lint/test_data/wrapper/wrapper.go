package wrapper

type Wrapper struct {
	Str string
}
