import { linterFmtTest } from "tests";

linterFmtTest({ linterName: "prisma" });
