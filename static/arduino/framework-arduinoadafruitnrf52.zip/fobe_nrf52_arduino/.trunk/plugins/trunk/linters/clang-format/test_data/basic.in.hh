int foo() {
}

inline int bar() {}

inline int baz() {
int a = 1;
int b=a*2;
return   b;
}
