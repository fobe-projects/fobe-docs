import { linterCheckTest } from "tests";

linterCheckTest({ linterName: "cfnlint" });
