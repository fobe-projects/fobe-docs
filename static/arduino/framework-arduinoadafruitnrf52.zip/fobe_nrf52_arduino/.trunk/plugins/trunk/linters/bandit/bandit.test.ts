import { linterCheckTest } from "tests";

// TODO(Tyler): We will eventually need to add a couple more test cases involving failure modes.
linterCheckTest({ linterName: "bandit" });
