#include "b.hh"
#include "c.hh"

inline void F() {
  A();
  C();
}
