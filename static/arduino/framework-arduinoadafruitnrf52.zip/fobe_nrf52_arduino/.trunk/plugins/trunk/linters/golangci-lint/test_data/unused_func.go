package main

import "fmt"

func helper() {
	fmt.Println("✋ World!")
}
