import { linterFmtTest } from "tests";

linterFmtTest({ linterName: "terragrunt" });
