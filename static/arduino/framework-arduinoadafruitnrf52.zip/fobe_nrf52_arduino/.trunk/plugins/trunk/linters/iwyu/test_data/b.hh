#pragma once
#include "a.hh"
void B() {}
