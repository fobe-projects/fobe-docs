package main

func foo() string {
	foo :=
		"bar"
	return foo
}
