import { linterFmtTest } from "tests";

linterFmtTest({ linterName: "svgo" });
