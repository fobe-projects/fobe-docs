import { linterCheckTest } from "tests";

linterCheckTest({ linterName: "markdownlint" });
