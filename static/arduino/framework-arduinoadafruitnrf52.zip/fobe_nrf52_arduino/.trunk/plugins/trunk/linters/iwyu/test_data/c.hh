#pragma once
#include "b.hh"
void C() {}
