class        Plumbus
  private






 def smooth; end
end

Klass.(
  key_1: 'hello',
  key_2: 'world'
)
