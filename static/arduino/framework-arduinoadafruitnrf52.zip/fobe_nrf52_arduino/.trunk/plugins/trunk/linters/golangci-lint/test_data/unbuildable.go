//go:build ignore

// The above build constraint forces this package to have no buildable Go files to produce an error in golangci-lint.

package main

func main() {
}
