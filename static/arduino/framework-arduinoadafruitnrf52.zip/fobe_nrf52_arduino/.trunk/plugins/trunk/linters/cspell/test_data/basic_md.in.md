# bad.md

# This file has reallly long lines

Line is OK- Make a realy long line that breaks the layout rules completely. Make a realy long line
that breaks
But this should be ignored because of config


Line is to long (over 120) A B C D E F G A B C D E F G A B C D E F G A B C D E F G A B C D E F G A B C D E F G A B C D E F G A B C D E F G
