import { linterFmtTest } from "tests";

linterFmtTest({ linterName: "txtpbfmt", namedTestPrefixes: ["test0", "test1"] });
