# Hello world

Type|Size(bit)|Wrapper Class
-|-|-
byte|8|Byte
char|16|Character
