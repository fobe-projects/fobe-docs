import { linterCheckTest } from "tests";

linterCheckTest({ linterName: "regal" });
