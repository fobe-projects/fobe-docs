import { linterCheckTest } from "tests";

linterCheckTest({ linterName: "markdownlint-cli2" });
