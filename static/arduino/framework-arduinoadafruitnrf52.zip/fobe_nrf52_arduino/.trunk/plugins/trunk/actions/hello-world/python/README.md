# hello-world python

To enable run `trunk actions enable hello-world-python`

To run `trunk run hello-world-python` or `git commit`
