# go-mod-tidy

Run `go mod tidy` whenever go.mod file is modified
