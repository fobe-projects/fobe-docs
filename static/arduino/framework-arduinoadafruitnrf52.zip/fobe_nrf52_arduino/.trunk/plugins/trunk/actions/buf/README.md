# buf-gen

Generates files from `.proto` files using [`buf`](https://buf.build) whenever protobuf files change.
**Must** have a `buf.gen.yaml` and `buf.work.yaml` (if running from project root)
