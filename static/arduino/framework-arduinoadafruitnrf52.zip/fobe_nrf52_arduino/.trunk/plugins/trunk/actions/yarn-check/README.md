# yarn-check

Monitors changes to `package.json` and `yarn.lock` to verify whether your yarn install is
up-to-date. Enable `yarn-check`, and you'll never have to worry about out-of-date node_modules
again!
