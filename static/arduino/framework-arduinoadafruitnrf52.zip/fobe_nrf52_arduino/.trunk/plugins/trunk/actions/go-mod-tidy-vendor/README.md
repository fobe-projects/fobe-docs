# go-mod-tidy-vendor

Run `go mod tidy` followed by `go mod vendor` whenever go.mod file is modified
