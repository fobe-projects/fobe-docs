import { toolInstallTest } from "tests";

toolInstallTest({
  toolName: "clangd",
  toolVersion: "16.0.2",
});
