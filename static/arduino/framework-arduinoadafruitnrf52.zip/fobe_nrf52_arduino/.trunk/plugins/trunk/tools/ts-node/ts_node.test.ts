import { toolInstallTest } from "tests";
toolInstallTest({
  toolName: "ts-node",
  toolVersion: "10.9.1",
});
