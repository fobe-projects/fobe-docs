import { toolInstallTest } from "tests";

toolInstallTest({
  toolName: "platformio",
  toolVersion: "6.1.11",
});
