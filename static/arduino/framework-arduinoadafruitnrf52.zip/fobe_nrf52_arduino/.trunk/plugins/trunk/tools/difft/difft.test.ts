import { toolInstallTest } from "tests";

toolInstallTest({
  toolName: "difft",
  toolVersion: "0.56.1",
});
