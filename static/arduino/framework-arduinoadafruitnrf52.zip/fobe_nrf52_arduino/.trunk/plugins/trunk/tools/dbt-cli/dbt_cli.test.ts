import { toolInstallTest } from "tests";

toolInstallTest({
  toolName: "dbt-cli",
  toolVersion: "0.38.14",
});
