import { toolInstallTest } from "tests";

toolInstallTest({
  toolName: "grpcui",
  toolVersion: "1.4.1",
});
