import { toolInstallTest } from "tests";
toolInstallTest({
  toolName: "clangd-indexing-tools",
  toolVersion: "16.0.2",
});
